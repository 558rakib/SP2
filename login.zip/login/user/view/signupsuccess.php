<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign UP Successfull</title>
</head>

<body>
    <h1>sign up successfull. Wait for approval.</h1>
    <a href="./signin.php">Back to Sign In</a>
</body>
</html>
